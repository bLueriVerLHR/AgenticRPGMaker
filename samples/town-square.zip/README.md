# AgenticRPGMaker — portable game package (www/)

This folder is the **portable game** (docs/01-vision.md §3, docs/02-open-questions.md
RQ1): a self-contained RPG-Maker-style bundle that runs on **any static host, any
modern browser, and JoiPlay-type mobile HTML runtimes** — no Node.js, no server,
no install required for single-player.

## Layout

| Path                         | Purpose                                                                                   |
| ---------------------------- | ----------------------------------------------------------------------------------------- |
| `index.html`               | The shipped player page (loads `js/runtime.js`, calls `boot()`).                       |
| `js/runtime.js`            | Bundled runtime + core + renderer (plain browser JS, ES2020, zero Node APIs).             |
| `data/manifest.json`       | Build-generated load list of maps + tilesets (static-host friendly, no directory listing).|
| `data/maps/*.map.json`     | Sample map(s), validated against the core map schema (ADR-003).                           |
| `data/tilesets/*.tileset.json` | Sample tileset(s), validated against the core tileset schema (ADR-003).               |
| `data/project.json`        | Sample project manifest (validated against the core project schema).                      |
| `img/tilesets/placeholder.png` | Generated placeholder atlas (deterministic, 128×128, 8×8 tiles of 16 px).              |
| `audio/`                   | Intentionally empty — audio is an MVP non-goal (see `audio/README.md`).                 |

## How to run

### Any static host

Upload/copy this folder anywhere and serve it over HTTP(S), e.g.:

```sh
python3 -m http.server 8000 --directory www
# or
npx serve www
```

then open `http://localhost:8000/`. Single-player works immediately; saves go to
IndexedDB (docs/08 §4.7).

### JoiPlay-type mobile runtime

Copy the whole folder onto the device, import it in JoiPlay (or equivalent),
and point it at `index.html`. On-screen D-pad + A/B buttons are provided for
touch input (docs/08 §4.4). A weak/absent WebGL environment automatically falls
back to the Canvas2D renderer (RQ2).

### Via the C++ server (local launcher mode)

```sh
agenticrpg-server --www-root www --editor-root editor --port 8080
# open http://localhost:8080/
```

### Multiplayer (VPS mode)

Run the server on a machine reachable by your players (it binds 0.0.0.0 by
default) and open the game with the relay URL:

```sh
agenticrpg-server --www-root www --port 8080
# browser 1: http://host:8080/?server=ws://host:8080/ws&room=demo&name=Alice
# browser 2: http://host:8080/?server=ws://host:8080/ws&room=demo&name=Bob
```

TLS is out of scope for the MVP (docs/06-architecture.md §6); put a reverse
proxy in front for public deployments.

## Compatibility notes

- Conservative web APIs only: no File System Access API, no OPFS requirement,
  no Node APIs, no `file://` fetches, no remote webfonts (system font stack),
  WebGL1-compatible subset with automatic Canvas2D fallback
  (docs/08-compatibility-checklist.md).
- Rebuild with `pnpm build:www` (see repo `AGENTS.md`).
